=====
Pentagon
=====

Pentagon is a Django app to collect online new admission form for Lake Montfort School.

Quick start
-----------

1. Add "pentagon" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'pentagon',
    ]

2. Include the following in URLconf of your project's urls.py like this::
	
	urlpatterns = [
    path('', views.home, name='home'),
    path('new_admission/', include('pentagon.urls')),
    path('admin/', admin.site.urls),
    path('captcha/', include('captcha.urls')),
]
    

3. Run ``python manage.py migrate`` to create the required models.

4. Start the development server and visit http://127.0.0.1:8000/
   to test pentagon (you'll need the Admin app enabled).
